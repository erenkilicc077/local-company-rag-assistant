# Gerçek demo görüntüleri

Bu depoya henüz geliştiricinin son çalışan n8n kurulumundan alınmış ekran görüntüsü veya uçtan uca model test raporu eklenmemiştir. Aşağıdakiler ekleme rehberidir; başarı kanıtı olarak sunulmaz.

## Kısa ekran kaydı önerisi

1. İndeksleme ve sohbet workflow'larının genel görünümünü göster.
2. Kaynakta bulunan bir soruyu sor, yanıt ve kaynak bağlantısını göster.
3. Kaynakta bulunmayan bir soruyu sor, bilgi bulunamadığını belirten cevabı göster.

Bekleme sürelerini kesersen videoyu hız ölçümü gibi sunma. Yanıtın kaynakla eşleştiğini kontrol et.

## Görseller

Doğrudan ekran alıntısı kullan; telefonla çekilmiş masa/monitör fotoğrafı yerine arayüzü okunaklı göster. Görselleri eklemek istersen `docs/images/workflows.png` ve `docs/images/grounded-answer.png` yollarını kullanıp README'ye bağlantı ekleyebilirsin.

API anahtarı, parola, token, kişisel tarayıcı sekmeleri, başka proje bilgileri, müşteri verisi veya yedek içerikleri görünmemeli. Şirketin logosunu/otel fotoğrafını tanıtım görseline taşımadan önce kullanım iznini kontrol et. Şirket içeriklerini topluca yeniden yayımlama.

## Canlı test raporu

| Senaryo | Gerçek soru | Gerçek yanıt ve kaynak kontrolü |
|---|---|---|
| Hizmet sorusu | Çalıştırınca doldur | Çalıştırınca doldur |
| Belirli bilgi | Çalıştırınca doldur | Çalıştırınca doldur |
| Belgede olmayan bilgi | Çalıştırınca doldur | Çalıştırınca doldur |

Şirketin açıklanmamış planları, özel görüşmeler veya departman bütçeleriyle ilgili örnekleri kamuya açık tanıtımda kullanma. Belge dışı bilgi testinde genel bir gelecek fiyatı sorusu yeterlidir.
