const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const {AsyncFunction} = {AsyncFunction:Object.getPrototypeOf(async function(){}).constructor};
const R = require('../src/rag.cjs');
const V = () => Array.from({length:768},(_,i)=>i===0?1:0);
const prepared = () => R.prepareDocuments(R.SOURCES.map((_,i)=>({content:[('Kaynak '+i+' hakkında doğrulanabilir metin. ').repeat(40)]})),R.SOURCES,R.CONFIG,'2026-11-10T00:00:00Z');
test('chunks cover all source characters, exact overlap and maximum size',()=>{
 const text='abcdefghijklmnopqrstuvwxyz'.repeat(150);const parts=R.splitText(text,800,100);
 assert.equal(parts[0].start,0);assert.equal(parts.at(-1).end,text.length);
 for(let i=0;i<parts.length;i++) { assert.ok(parts[i].text.length<=800); if(i)assert.equal(parts[i-1].text.slice(-100),parts[i].text.slice(0,100)); }
});
test('invalid overlap rejected',()=>assert.throws(()=>R.splitText('abc',100,100)));
test('two documents are required, not a silent one-page success',()=>assert.throws(()=>R.prepareDocuments([{content:['x'.repeat(500)]}],R.SOURCES,R.CONFIG)));
test('empty HTML selector output stops indexing',()=>assert.throws(()=>R.prepareDocuments([{content:[]},{content:['x'.repeat(500)]}],R.SOURCES,R.CONFIG)));
test('two sources retain correct source metadata and distinct stable IDs',()=>{
 const p=prepared();assert.equal(p.documents.length,2);assert.equal(new Set(p.chunks.map(c=>c.id)).size,p.chunks.length);
 for(const c of p.chunks)assert.ok(R.SOURCES.some(s=>s.source_id===c.metadata.source_id&&s.url===c.metadata.source_url));
 assert.deepEqual(p.chunks.map(c=>c.id),prepared().chunks.map(c=>c.id));
});
test('batch vector validation rejects count mismatch, wrong dimension and zero vectors',()=>{
 assert.throws(()=>R.checkVectors({embeddings:[]},1,768));assert.throws(()=>R.checkVectors({embeddings:[[1,2]]},1,768));
 assert.throws(()=>R.checkVectors({embeddings:[Array(768).fill(0)]},1,768));
 assert.throws(()=>R.checkVectors({embeddings:[V().map((x,i)=>i===0?NaN:x)]},1,768));
});
test('upsert and scoped stale deletion preserve the live ID set',()=>{
 const p=prepared();const points=R.preparePoints({embeddings:p.chunks.map(V)},p);
 assert.equal(points.points.length,p.chunks.length);
 assert.deepEqual(R.staleFilter(p).filter.must_not[0].has_id,p.chunks.map(c=>c.id));
 assert.equal(R.staleFilter(p).filter.must[0].match.value,R.CONFIG.dataset);
});
test('summary is actual database count and rejects mismatch',()=>{
 const p=prepared();assert.throws(()=>R.indexSummary({result:{count:0}},p));
 const s=R.indexSummary({result:{count:p.chunks.length}},p);assert.equal(s.document_count,2);assert.equal(s.chunk_count,p.chunks.length);
});
test('query uses same embedding model and correct top-k dataset filter',()=>{
 const q=R.prepareQuestion({chatInput:'Rezervasyon teyidi nasıl gönderilir?'},R.CONFIG);
 assert.equal(q.embedding_request.model,R.CONFIG.embedding_model);
 const req=R.queryRequest({embeddings:[V()]},q);assert.equal(req.limit,4);assert.equal(req.filter.must[0].match.value,R.CONFIG.dataset);
});
const context=()=>R.prepareContext({result:{points:[{id:1,score:.8,payload:{text:'Rezervasyon tamamlandıktan sonra e-posta yoluyla onay belgesi gönderilir.',dataset:R.CONFIG.dataset,embedding_model:R.CONFIG.embedding_model,source_id:R.SOURCES[1].source_id,source_title:R.SOURCES[1].title,source_url:R.SOURCES[1].url}}]}},R.prepareQuestion({chatInput:'Teyit nasıl gönderilir?'},R.CONFIG));
const model=(answerable,answer,citations)=>({done:true,done_reason:'stop',message:{content:JSON.stringify({answerable,answer,citations})}});
test('grounded model response renders only source URLs from retrieved payload',()=>{
 const out=R.renderAnswer(model(true,'Onay belgesi e-posta ile gönderilir.',[{chunk:1,quote:'e-posta yoluyla onay belgesi gönderilir.'}]),context());
 assert.equal(out.answerable,true);assert.equal(out.used_sources.length,1);assert.ok(out.output.includes(R.SOURCES[1].url));
});
test('fabricated chunk reference, quote, incomplete model and malformed JSON are rejected',()=>{
 for(const raw of [model(true,'X',[{chunk:2,quote:'e-posta yoluyla onay belgesi gönderilir.'}]),model(true,'X',[{chunk:1,quote:'Uydurulmuş bir kanıt alıntısı.'}]),{done:false}, {done:true,message:{content:'not json'}}])assert.equal(R.renderAnswer(raw,context()).validation_error,true);
});
test('unknown information and empty retrieval produce canonical refusal without source claims',()=>{
 const out=R.renderAnswer(model(false,'Uydurulmuş yanıt',[]),context());assert.equal(out.output,R.UNKNOWN);assert.deepEqual(out.used_sources,[]);
 const empty=R.prepareContext({result:{points:[]}},R.prepareQuestion({chatInput:'Bütçe kaç TL?'},R.CONFIG));assert.equal(R.renderAnswer({},empty).output,R.UNKNOWN);
});
test('external or mismatched metadata cannot become a source citation',()=>assert.throws(()=>R.prepareContext({result:{points:[{payload:{text:'x',dataset:R.CONFIG.dataset,embedding_model:R.CONFIG.embedding_model,source_id:'x',source_url:'https://example.com'}}]}},R.prepareQuestion({chatInput:'x'},R.CONFIG))));
for (const name of ['01_Kirman_Indeksleme.json','02_Kirman_Sohbet.json']) {
 const base=fs.existsSync(path.join(__dirname,'..',name)) ? path.join(__dirname,'..') : path.join(__dirname,'../workflows');
 const w=JSON.parse(fs.readFileSync(path.join(base,name)));
 test(name+': all connections exist and all code nodes compile',()=>{
  const nodes=new Map(w.nodes.map(n=>[n.name,n]));
  for(const [from,types] of Object.entries(w.connections)){assert.ok(nodes.has(from));for(const groups of Object.values(types))for(const group of groups)for(const edge of group)assert.ok(nodes.has(edge.node));}
  for(const n of w.nodes)if(n.type==='n8n-nodes-base.code')new AsyncFunction('$input','$',n.parameters.jsCode);
  assert.equal(w.active,false);assert.deepEqual(w.pinData,{});assert.ok(!w.nodes.some(n=>n.credentials));
 });
 test(name+': JSON body and URL expressions are valid JavaScript',()=>{
  for(const n of w.nodes)for(const key of ['jsonBody','url']){const val=n.parameters[key];if(typeof val==='string'&&val.startsWith('={{'))new Function('$json','$','return ('+val.slice(3,-2).trim()+')');}
 });
}
