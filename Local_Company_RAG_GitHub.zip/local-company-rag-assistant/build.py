import json
from pathlib import Path
from uuid import uuid5, NAMESPACE_URL

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'workflows'
OUT.mkdir(exist_ok=True)
DOMAIN = (ROOT / 'src/rag.cjs').read_text().split('module.exports =')[0]

def ident(name): return str(uuid5(NAMESPACE_URL, 'eren-kirman-rag-v1:' + name))
def node(name, typ, params, pos, version=1):
    return {'id':ident(name),'name':name,'type':typ,'typeVersion':version,'position':pos,'parameters':params}
def code(name, body, pos):
    return node(name, 'n8n-nodes-base.code', {'mode':'runOnceForAllItems','jsCode':DOMAIN+'\n'+body},pos,2)
def http(name, method, url, pos, body=None, response='json', timeout=300000):
    params={'method':method,'url':url,'options':{'timeout':timeout,'response':{'response':{'responseFormat':response}}}}
    if response=='text': params['options']['response']['response']['outputPropertyName']='data'
    if body is not None: params.update(sendBody=True,specifyBody='json',jsonBody=body)
    return node(name,'n8n-nodes-base.httpRequest',params,pos,4.2)
def sticky(name, text, pos, width=1050,height=150):
    return node(name,'n8n-nodes-base.stickyNote',{'content':text,'width':width,'height':height},pos)
def workflow(name, nodes, chain, filename):
    connections = {a:{'main':[[{'node':b,'type':'main','index':0}]]} for a,b in zip(chain,chain[1:])}
    data={'name':name,'nodes':nodes,'connections':connections,'settings':{'executionOrder':'v1'},
          'active':False,'pinData':{},'staticData':None,'tags':[]}
    (OUT / filename).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')

index = [
 node('Baslat','n8n-nodes-base.manualTrigger',{},[0,120]),
 code('Ayarlar ve Kaynaklar','return SOURCES.map(source => ({json: {config: CONFIG, source}}));',[230,120]),
 http('Kaynak Sayfalari','GET','={{ $json.source.url }}',[460,120],response='text'),
 node('HTML Metinleri','n8n-nodes-base.html',{
   'operation':'extractHtmlContent','sourceData':'json','dataPropertyName':'data',
   'extractionValues':{'values':[{'key':'content','cssSelector':"={{ $('Ayarlar ve Kaynaklar').item.json.source.selector }}",
    'returnValue':'text','returnArray':True,'skipSelectors':'script, style, img, svg'}]},
   'options':{'trimValues':True,'cleanUpText':True}},[690,120],1.2),
 code('Parcalara Ayir',"const sources = $('Ayarlar ve Kaynaklar').all().map(x => x.json.source);\nreturn [{json: prepareDocuments($input.all().map(x => x.json), sources, $('Ayarlar ve Kaynaklar').first().json.config)}];",[920,120]),
 http('Embedding Uret','POST','={{ $json.config.ollama_url + "/api/embed" }}',[1150,120],
      body='={{ $json.embedding_request }}',timeout=600000),
 code('Qdrant Kaydini Hazirla',"return [{json: preparePoints($input.first().json, $('Parcalara Ayir').first().json)}];",[1150,350]),
 http('Qdrant Yaz','PUT',"={{ $('Parcalara Ayir').first().json.config.qdrant_url + '/collections/' + $('Parcalara Ayir').first().json.config.collection + '/points?wait=true' }}",[920,350],body='={{ $json }}'),
 http('Eski Parcalari Ayikla','POST',"={{ $('Parcalara Ayir').first().json.config.qdrant_url + '/collections/' + $('Parcalara Ayir').first().json.config.collection + '/points/delete?wait=true' }}",[690,350],body="={{ $('Parcalara Ayir').first().json.cleanup_request }}"),
 http('Kayit Sayisini Oku','POST',"={{ $('Parcalara Ayir').first().json.config.qdrant_url + '/collections/' + $('Parcalara Ayir').first().json.config.collection + '/points/count' }}",[460,350],body="={{ $('Parcalara Ayir').first().json.count_request }}"),
 code('Indeksleme Ozeti',"return [{json: indexSummary($input.first().json, $('Parcalara Ayir').first().json)}];",[230,350]),
]
index.append(sticky('Not - Indeksleme','## 1 - Belgeleri indeksle\nKurulum.ps1 tamamlandıktan sonra Execute workflow. Kaynaklar canlı resmî sayfalardan indirilir. 800/100 karakter, embeddinggemma:300m, 768 boyut, Cosine. Son adım gerçek belge/parça sayısını verir.\nYeniden çalıştırma aynı veri setindeki eski parçaları günceller; sohbeti aynı anda kullanmayın.',[0,-100],1400,150))
workflow('Company RAG - 1 Index Documents (Independent Demo)',index,[n['name'] for n in index if n['type']!='n8n-nodes-base.stickyNote'],'01_Kirman_Indeksleme.json')

chat_trigger = node('Sohbet','@n8n/n8n-nodes-langchain.chatTrigger',{
    'public':False,'availableInChat':False,'mode':'hostedChat',
    'initialMessages':'Merhaba! Kirman Premium kaynakları hakkında soru sorabilirsiniz. Bu bir öğrenci demosudur.',
    'options':{'responseMode':'lastNode','loadPreviousSession':'notSupported'}},[0,120],1.1)
chat_trigger['webhookId']=ident('kirman-rag-chat-webhook')
chat = [chat_trigger,
 code('Soruyu Hazirla','return [{json: prepareQuestion($input.first().json, CONFIG)}];',[240,120]),
 http('Soruyu Vektorle','POST','={{ $json.config.ollama_url + "/api/embed" }}',[480,120],body='={{ $json.embedding_request }}',timeout=600000),
 code('Aramayi Hazirla',"return [{json: queryRequest($input.first().json, $('Soruyu Hazirla').first().json)}];",[720,120]),
 http('Qdrant Ara','POST',"={{ $('Soruyu Hazirla').first().json.config.qdrant_url + '/collections/' + $('Soruyu Hazirla').first().json.config.collection + '/points/query' }}",[960,120],body='={{ $json }}'),
 code('Kaynaktan Istek Hazirla',"return [{json: prepareContext($input.first().json, $('Soruyu Hazirla').first().json)}];",[960,350]),
 http('Qwen Yanitla','POST',"={{ $('Soruyu Hazirla').first().json.config.ollama_url + '/api/chat' }}",[720,350],body='={{ $json.chat_request }}',timeout=600000),
 code('Kaynakli Cevap',"return [{json: renderAnswer($input.first().json, $('Kaynaktan Istek Hazirla').first().json)}];",[480,350]),
 sticky('Not - Sohbet','## 2 - Kaynaklara dayalı sohbet\nOpen chat ile n8n editörü içinde test edin. Public kapalı, responseMode=lastNode; son düğüm output alanı döndürür. Telegram ve Cloudflare gerekmez.\nSoru embedding → Qdrant Top-K=4 → kaynak metinleri → qwen3:14b → alıntı ve kaynak doğrulaması. Sohbet geçmişi modele taşınmaz; soruları tam yazın.',[0,-110],1200,160),
]
workflow('Company RAG - 2 Source Grounded Chat (Independent Demo)',chat,[n['name'] for n in chat if n['type']!='n8n-nodes-base.stickyNote'],'02_Kirman_Sohbet.json')
print('Built:',*[x.name for x in OUT.glob('*.json')])
