# Local Company RAG Assistant

**n8n · Ollama · Qdrant · Qwen3 14B · EmbeddingGemma**

Şirket kaynaklarında ilgili bilgiyi arayıp, bulduğu metinlerle yanıt oluşturan yerel bir RAG chatbot prototipi. Tech İstanbul Chatbot ve Konuşma AI Geliştirme Bootcamp çalışması kapsamında geliştirildi.

**Bağımsız öğrenci/portföy projesidir. Kirman Premium tarafından sipariş edilmiş, onaylanmış veya kullanılan resmî bir ürün değildir; şirketle iş birliği ya da temsil ilişkisi ifade etmez.**

Kirman Premium'un kamuya açık tanıtım ve SSS sayfaları, yerel çalışmada şirket bilgisi senaryosuna örnek olarak seçilmiştir. Bu depoda şirket belgelerinin kopyası, logo, otel fotoğrafı, vektör veritabanı veya model ağırlıkları dağıtılmaz. Bir sayfanın erişilebilir olması, içeriğin her kullanımına veya yeniden dağıtımına izin verildiği anlamına gelmez. Kaynakları kullanmadan önce güncel koşulları ve gerekli izinleri kontrol edin.

## Problem ve yaklaşım

Şirket hakkında genel model bilgisine dayanarak verilen bir yanıt güncel olmayabilir veya doğrulanamayabilir. Bu prototip, soruyla ilgili kaynak parçalarını getirerek modelin bu metinlere dayanmasını hedefler. Yanıt üretimi ve kaynak doğrulaması ayrı adımlardır.

1. **İndeksleme:** İzin verilen kaynak sayfalarının metinlerini alma → ilgili HTML bölümlerini ayıklama → karakter bazlı parçalama → embedding → Qdrant'a metin ve metadata yazma.
2. **Sohbet:** Soru → aynı embedding modeli → Qdrant'tan Top-K arama → kaynak metinlerini Qwen'e verme → JSON yanıtını ve birebir kanıt alıntılarını kontrol etme → kaynak bağlantılı cevap.

İki workflow birbirini çağırmaz; aynı Qdrant koleksiyonuna yazıp okuyarak birlikte çalışır. Model ağırlıkları eğitilmez veya fine-tune edilmez.

## Özellikler

- İndeksleme ve sohbet için iki ayrı n8n workflow'u.
- Yerel Ollama modelleri; bu yapılandırmada ücretli bir model API'si veya bulut LLM çağrısı kullanılmaz.
- Her metin parçasında kaynak URL'si, başlığı, alınma zamanı ve chunk ayarları.
- Kaynak içeriği boşsa indekslemeyi durdurma.
- Embedding vektör sayısı ve boyutu kontrolü.
- Kararlı kayıt ID'leriyle tekrar indeksleme ve aynı veri setindeki eski parçaları ayıklama.
- Modelin verdiği kanıt alıntısının getirilen metinde bulunmasını kontrol etme.
- Kaynakta bilgi bulunmadığında bunu belirtmeye yönelik istem ve doğrulama akışı.
- Gerçek doküman ve chunk sayısını veren indeksleme özeti.

## Yapılandırma

| Parametre | Varsayılan |
|---|---|
| Chat LLM | `qwen3:14b` |
| Embedding modeli | `embeddinggemma:300m` |
| Vector DB | Qdrant |
| Mesafe / boyut | Cosine / 768 |
| Chunk size / overlap | 800 / 100 |
| Birim | Karakter, JavaScript UTF-16 uzunluğu |
| Top-K | 4 |
| Arayüz | n8n Chat Trigger, editör test sohbeti |
| Koleksiyon | `eren_kirman_rag_v1` |

Doküman ve chunk sayısı sabit bir başarı metriği değildir; canlı indeksleme özetinden okunur. Top-K, modelin token örnekleme ayarı değildir; getirilen metin parçası sayısıdır.

## Kaynak referansları

- https://www.kirmanpremium.com/tr
- https://www.kirmanpremium.com/tr/sikca-sorulan-sorular

HTML seçicileri `src/rag.cjs` içindeki `SOURCES` yapılandırmasındadır. Sitenin HTML yapısı değişirse seçicilerin güncellenmesi gerekebilir. Kaynak değiştirirken metinleri kullanma hakkını kontrol edin. Şirket içi belge, müşteri bilgisi veya erişim engeli bulunan içerik kullanmayın.

## Yerel kurulum

Bu örnek Windows + Docker Desktop + yerel Ollama kurulumuna göre hazırlanmıştır. Mevcut n8n Docker container'ının adı `n8n`, portu `5678` olmalıdır. Hazırlama scripti mevcut n8n'i silmez veya yeniden oluşturmaz; ayrı bir Qdrant servisi ve ek ağ oluşturur.

1. Docker Desktop ve Ollama'yı açın. n8n hesabınızı mevcut yerel kurulumunuzdan kullanın.
2. Modelleri indirin:

```powershell
ollama pull qwen3:14b
ollama pull embeddinggemma:300m
```

3. Proje kökünde PowerShell açıp hazırlama scriptini çalıştırın:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\Kurulum.ps1
```

4. `http://127.0.0.1:5678` adresinde, her dosyayı **ayrı boş bir workflow'a** `Import from File` ile aktarın:
   - `workflows/01_Kirman_Indeksleme.json`
   - `workflows/02_Kirman_Sohbet.json`
5. İlk workflow'un tamamını `Execute workflow` ile çalıştırın. Son düğümde `INDEKSLEME_TAMAM`, iki doküman ve sıfırdan büyük gerçek chunk sayısını doğrulayın.
6. İkinci workflow'da `Open chat` açıp tam bir soru yazın. Test sohbeti için Telegram veya Cloudflare gerekmez.

Ollama en az 0.11.10 olmalıdır. Docker içinden Windows Ollama adresi `http://host.docker.internal:11434`, Qdrant adresi `http://eren-rag-qdrant:6333` olarak ayarlıdır. Donanıma bağlı olarak 14B model RAM/CPU'ya da yüklenebilir; yanıt gecikmesi bu projede ölçülmemiştir. `keep_alive: 0` bellek yükünü azaltmak için kullanılır ve yeniden model yükleme süresini artırabilir.

Eski bir dış webhook adresi n8n'de tanımlıysa yerel sohbetin istek adresini kontrol edin. Bu depo, var olan sunucunun webhook ayarını otomatik değiştiren veya veri diski yedeği alan onarım scriptlerini içermez. Mevcut sunucunuzun yapılandırmasını ayrıca yönetin.

Qdrant kalıcı volume kullanır. Yerel örnek API anahtarsızdır ve host portu yalnızca `127.0.0.1` üzerinde yayınlanır; bu yapılandırmayı doğrudan herkese açık servis olarak kullanmayın.

## Kod ve workflow üretimi

`src/rag.cjs` kaynak kodun okunabilir hâlidir. n8n'e import edilecek JSON'larda bu fonksiyonlar Code düğümlerine gömülüdür; çalıştırmak için n8n'e dosya kopyalamak gerekmez.

Python 3 ile workflow dosyalarını yeniden üretmek için:

```text
python build.py
```

Bu komut `workflows/` içindeki iki JSON dosyasını günceller. Kaynakları değiştirdiyseniz iki workflow'u da yeni sürümleriyle kullanın ve indekslemeyi yeniden yapın. Farklı embedding modeli/boyutu için aynı koleksiyonu düşünmeden yeniden kullanmayın.

## Testler ve kanıt sınırı

Node.js 22+ ile ek npm bağımlılığı kurmadan:

```text
npm test
```

17 test; parçalama, metadata, vektör doğrulaması, veri seti kapsamı, sorgu ayarları, alıntı doğrulaması ve workflow yapısını kontrol eder. Testlerde sentetik örnekler kullanılır. Bunlar gerçek Ollama yanıt kalitesini, n8n sunucusunu veya canlı Qdrant entegrasyonunu ölçmez.

Ek ifade kontrolünde, n8n 2.44.6'nın kullandığı `n8n-workflow@2.44.2` değerlendiricisiyle ilk sürümdeki ifade hatası yeniden üretilmiş ve basit alan referanslarıyla düzeltilmiştir. Bu kontrol de uçtan uca çalışma testi değildir.

Gerçek demo için şu senaryoları çalıştırın:

1. Kaynaklarda bulunan bir hizmet hakkında soru.
2. Kaynaktan doğrulanabilen belirli bir bilgi hakkında soru.
3. Yüklenen kaynaklarda yer almayan bir gelecek fiyatı veya ayrıntı hakkında soru.

Yanıtları kaynakla karşılaştırın. Ölçülmüş bir doğruluk yüzdesi, performans kazancı veya maliyet düşüşü raporlanmamaktadır. Gerçek demo kanıtları için [docs/DEMO.md](docs/DEMO.md) dosyasına bakın.

## Sınırlamalar

- Alıntı doğrulaması, alıntının metinde bulunduğunu kanıtlar; cevaptaki her iddianın anlamsal olarak doğru olduğunu garanti etmez.
- Kaynak bilgisinin doğruluğu ve güncelliği otomatik doğrulanmaz.
- Sohbet geçmişi modele gönderilmez; takip soruları tam yazılmalıdır.
- İndeksleme sırasında sohbet kullanmayın; bu küçük demo eşzamanlı güncellemeler için test edilmemiştir.
- Kamuya açık rezervasyon, ödeme veya müşteri hizmeti servisi değildir.

## Gizlilik ve paylaşım

Yalnızca bu depodaki temiz şablon ve kaynak kod dosyalarını paylaşın. n8n/SQLite yedekleri, `.env`, credential export'ları, Docker inspect çıktıları, Qdrant storage, ham şirket içerikleri ve model ağırlıkları depoya eklenmemelidir. `.gitignore`, dosyaları tarayıcıdan elle yüklediğinizde sizi otomatik olarak korumaz.

Kendi n8n JSON dışa aktarımınızı kullanırsanız `credentials`, `pinData`, `staticData` ve HTTP header/body alanlarını ayrıca inceleyin. `docs/DEMO.md` içindeki görseller için de aynı gizlilik kontrolü geçerlidir.

## Lisans ve haklar

Bu depodaki özgün kod MIT lisansıyla sunulur. Bu lisans, Kirman Premium'a ait içerik, marka, logo, tasarım veya üçüncü taraf modellere ilişkin kullanım izni vermez. Ayrıntılar: [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).

## Geliştirici

Eren Kılıç — Yönetim Bilişim Sistemleri son sınıf öğrencisi.

GitHub: https://github.com/erenkilicc077
