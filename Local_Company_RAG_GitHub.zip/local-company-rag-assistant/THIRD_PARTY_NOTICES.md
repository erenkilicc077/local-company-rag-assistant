# Üçüncü taraf hakları

Bu depo bağımsız bir eğitim/portföy çalışmasıdır. Kirman Premium'un resmî ürünü, onaylı uygulaması veya şirket adına sunulan bir hizmet değildir.

Kirman Premium adı ve kaynak sayfa bağlantıları örnek senaryoyu ve referans kaynaklarını tanımlamak amacıyla kullanılır. Şirkete ait logo, fotoğraf, web tasarımı, indirilen kaynak belge, vektör veri tabanı veya model ağırlığı bu depoda dağıtılmaz.

MIT lisansı yalnızca bu deponun özgün kodunu kapsar; şirket içeriğine veya markasına ilişkin bir lisans değildir. Kaynaklara erişim, içeriği yeniden dağıtma izni olarak değerlendirilmemelidir. İndeksleme, yeniden kullanım, yayın veya marka materyali kullanımı öncesinde ilgili hak ve güncel koşullar ayrıca incelenmelidir. Bu açıklama izin yerine geçmez.

Kirman'ın yayımladığı koşullar: https://www.kirmanpremium.com/leodikya-kirman-premium/tr/mesafeli-satis-sozlesmesi

n8n, Ollama, Qdrant ve kullanılan modeller kendi lisanslarına/koşullarına tabidir. Bu depoya verilen lisans bu projelerin lisanslarını değiştirmez.
