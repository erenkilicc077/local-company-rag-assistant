﻿$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Run-Docker([string[]]$DockerArgs) {
    & docker @DockerArgs
    if ($LASTEXITCODE -ne 0) { throw ('Docker komutu basarisiz: docker ' + ($DockerArgs -join ' ')) }
}
function Read-Container([string]$Name) {
    $allNames = @(& docker ps -a --format '{{.Names}}')
    if ($LASTEXITCODE -ne 0) { throw 'Docker Desktop acik degil.' }
    if ($allNames -notcontains $Name) { return $null }
    $raw = & docker inspect $Name
    if ($LASTEXITCODE -ne 0) { throw ($Name + ' okunamadi.') }
    return @($raw | ConvertFrom-Json)[0]
}
function Ensure-Network([string]$Name, $Container) {
    $names = @($Container.NetworkSettings.Networks.PSObject.Properties.Name)
    if ($names -notcontains $Name) { Run-Docker -DockerArgs @('network','connect',$Name,$Container.Name.TrimStart('/')) }
}

try {
    Write-Host '[1/6] Mevcut Docker ve n8n kontrol ediliyor...'
    $null = Get-Command docker -ErrorAction Stop
    & docker info --format '{{.ServerVersion}}'
    if ($LASTEXITCODE -ne 0) { throw 'Once Docker Desktop uygulamasini acin.' }
    $n8nContainer = Read-Container 'n8n'
    if ($null -eq $n8nContainer) { throw 'n8n adli mevcut container bulunamadi. Yeni n8n olusturulmadi.' }
    # Ayni veri diskine iki n8n islemi yazmasin. Yalnizca container adlari gosterilir.
    $mountKeys = @($n8nContainer.Mounts | ForEach-Object { $_.Source })
    $conflicts = @()
    foreach ($otherName in @(& docker ps --format '{{.Names}}')) {
        if ($otherName -eq 'n8n') { continue }
        $other = Read-Container $otherName
        if (@($other.Mounts | Where-Object { $mountKeys -contains $_.Source }).Count -gt 0) {
            $conflicts += $otherName
        }
    }
    if ($conflicts.Count -gt 0) {
        throw ('n8n veri diskini kullanan baska container acik: ' + ($conflicts -join ', ') + '. Docker Desktop uzerinden bunlari STOP yapip scripti tekrar calistirin. SILMEYIN.')
    }
    if (-not $n8nContainer.State.Running) { Run-Docker -DockerArgs @('start','n8n') }

    Write-Host '[2/6] RAG icin ayri Docker agi hazirlaniyor...'
    $netName = 'eren-rag-net'
    $networks = @(& docker network ls --format '{{.Name}}')
    if ($LASTEXITCODE -ne 0) { throw 'Docker aglari okunamadi.' }
    if ($networks -notcontains $netName) { Run-Docker -DockerArgs @('network','create',$netName) }
    Ensure-Network $netName (Read-Container 'n8n')

    Write-Host '[3/6] Kalici veri diskiyle Qdrant aciliyor...'
    $qName = 'eren-rag-qdrant'
    $qContainer = Read-Container $qName
    if ($null -eq $qContainer) {
        Run-Docker -DockerArgs @('volume','create','eren_rag_qdrant_data')
        Run-Docker -DockerArgs @('run','-d','--name',$qName,'--label','io.eren.kirman-rag=1',
            '--restart','unless-stopped','--network',$netName,
            '-p','127.0.0.1:6333:6333','-v','eren_rag_qdrant_data:/qdrant/storage',
            'qdrant/qdrant:v1.19.1')
    } else {
        $label = $qContainer.Config.Labels.PSObject.Properties['io.eren.kirman-rag']
        if ($null -eq $label -or $label.Value -ne '1') { throw 'Ayni adli baska Qdrant bulundu. Degistirilmedi.' }
        if (-not $qContainer.State.Running) { Run-Docker -DockerArgs @('start',$qName) }
        Ensure-Network $netName (Read-Container $qName)
    }
    $ready = $false
    for ($attempt = 0; $attempt -lt 45; $attempt++) {
        try { $null = Invoke-RestMethod -Uri 'http://127.0.0.1:6333/readyz' -TimeoutSec 2; $ready = $true; break }
        catch { Start-Sleep -Seconds 1 }
    }
    if (-not $ready) { throw 'Qdrant acilmadi. docker logs --tail 30 eren-rag-qdrant ile kontrol edin.' }

    Write-Host '[4/6] Koleksiyon kontrol ediliyor (768 boyut, Cosine)...'
    $collectionUrl = 'http://127.0.0.1:6333/collections/eren_kirman_rag_v1'
    $create = $false
    try { $collection = Invoke-RestMethod -Uri $collectionUrl -TimeoutSec 10 }
    catch {
        if ($null -ne $_.Exception.Response -and [int]$_.Exception.Response.StatusCode -eq 404) { $create = $true }
        else { throw }
    }
    if ($create) {
        $null = Invoke-RestMethod -Method Put -Uri $collectionUrl -ContentType 'application/json' -Body '{"vectors":{"size":768,"distance":"Cosine"}}' -TimeoutSec 20
        $collection = Invoke-RestMethod -Uri $collectionUrl -TimeoutSec 10
    }
    if ($collection.result.config.params.vectors.size -ne 768 -or $collection.result.config.params.vectors.distance -ne 'Cosine') {
        throw 'Mevcut koleksiyon ayarlari farkli. Veri silinmedi; ayarlari elle kontrol edin.'
    }

    Write-Host '[5/6] n8n icinden Qdrant ve Ollama kontrol ediliyor...'
    $check = @'
(async () => {
  for (const [name,url] of [['Qdrant','http://eren-rag-qdrant:6333/collections/eren_kirman_rag_v1'],['Ollama','http://host.docker.internal:11434/api/tags']]) {
    const response = await fetch(url,{signal:AbortSignal.timeout(20000)});
    if (!response.ok) throw new Error(name + ': HTTP ' + response.status);
    const data = await response.json();
    if (name === 'Ollama') {
      const names = data.models.map(m=>m.name);
      console.log('Ollama modelleri: ' + names.join(', '));
      for (const required of ['qwen3:14b','embeddinggemma:300m']) {
        if (!names.includes(required)) throw new Error('Model eksik. PowerShell: ollama pull ' + required);
      }
    }
    console.log(name + ': OK');
  }
})().catch(e=>{console.error(e.message);process.exitCode=1;});
'@
    Run-Docker -DockerArgs @('exec','n8n','node','-e',$check)

    Write-Host '[6/6] n8n hazirlik kontrolu...'
    $n8nReady = $false
    for ($attempt = 0; $attempt -lt 45; $attempt++) {
        try { $null = Invoke-RestMethod -Uri 'http://127.0.0.1:5678/healthz' -TimeoutSec 2; $n8nReady = $true; break }
        catch { Start-Sleep -Seconds 1 }
    }
    if (-not $n8nReady) { throw 'n8n localhost:5678 uzerinde hazir degil. Mevcut port ayarini kontrol edin.' }
    Write-Host ''
    Write-Host 'KURULUM TAMAM. Mevcut n8n projeleri ve baglantilari korunmustur.' -ForegroundColor Green
    Write-Host 'Simdi 01_Kirman_Indeksleme.json ve 02_Kirman_Sohbet.json dosyalarini ayri workflow olarak import edin.'
    Write-Host 'Once indekslemeyi Execute workflow ile calistirin. Sonra sohbet workflowunda Open chat kullanin.'
    Write-Host 'Qdrant paneli: http://localhost:6333/dashboard'
    Start-Process 'http://localhost:5678'
} catch {
    Write-Host ''
    Write-Host ('HATA: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Hicbir container veya veri diski silinmedi. Hata giderildikten sonra ayni script tekrar calistirilabilir.'
    exit 1
}
